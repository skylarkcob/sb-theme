<div class="sb-social-share margin-bottom-10">
    <ul class="list-inline list-unstyled">
        <li><a target="_blank" href="<?php echo SB_Theme::get_social_share_url(array('social_name' => 'facebook')); ?>" class="btn btn-social btn-facebook"><i class="fa fa-facebook icon-left"></i> Facebook</a></li>
        <li><a target="_blank" href="<?php echo SB_Theme::get_social_share_url(array('social_name' => 'twitter')); ?>" class="btn btn-social btn-twitter"><i class="fa fa-twitter icon-left"></i> Twitter</a></li>
        <li><a target="_blank" href="<?php echo SB_Theme::get_social_share_url(array('social_name' => 'googleplus')); ?>" class="btn btn-social btn-googleplus"><i class="fa fa-google-plus icon-left"></i> Google+</a></li>
        <li><a target="_blank" href="<?php echo SB_Theme::get_social_share_url(array('social_name' => 'pinterest')); ?>" class="btn btn-social btn-pinterest"><i class="fa fa-pinterest icon-left"></i> Pinterest</a></li>
        <li><a target="_blank" href="<?php echo SB_Theme::get_social_share_url(array('social_name' => 'email')); ?>" class="btn btn-social btn-email"><i class="fa fa-envelope icon-left"></i> Email</a></li>
    </ul>
</div>