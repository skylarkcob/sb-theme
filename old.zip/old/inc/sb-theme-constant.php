<?php
define('SB_THEME_CUSTOM_PATH', untrailingslashit(get_template_directory()) . '/sb-theme-custom');

define('SB_THEME_CUSTOM_URL', untrailingslashit(get_template_directory_uri()) . '/sb-theme-custom');

define('SB_THEME_CUSTOM_INC_PATH', SB_THEME_CUSTOM_PATH . '/inc');

define('SB_THEME_LIB_PATH', SB_THEME_NEW_PATH . '/lib');

define('SB_THEME_LIB_URL', SB_THEME_NEW_URL . '/lib');

define('SB_THEME_DEFAULT_LANGUAGE', 'vi');